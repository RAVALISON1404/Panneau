create view besoin_necessaire(secteur, date, am, pm) as
SELECT secteur.id                                            AS secteur,
       besoin.date,
       besoin.puissance * sum(pointage.am)::double precision AS am,
       besoin.puissance * sum(pointage.pm)::double precision AS pm
FROM secteur
         JOIN besoin ON secteur.id = besoin.secteur_id
         JOIN salle ON secteur.id = salle.secteur_id
         JOIN pointage ON salle.id = pointage.salle_id AND pointage.date = besoin.date
GROUP BY secteur.id, besoin.date, besoin.puissance;

alter table besoin_necessaire
    owner to postgres;

