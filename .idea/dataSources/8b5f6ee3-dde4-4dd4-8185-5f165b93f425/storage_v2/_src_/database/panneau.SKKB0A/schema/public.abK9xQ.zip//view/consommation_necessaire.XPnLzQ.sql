create view consommation_necessaire(secteur, date, heure, panneau, batterie) as
SELECT secteur.id                                                 AS secteur,
       luminosite.date,
       luminosite.heure,
       luminosite.niveau * secteur.panneau / 10::double precision AS panneau,
       CASE
           WHEN EXTRACT(hour FROM luminosite.heure) >= 12::numeric THEN sum(besoin_necessaire.pm) -
                                                                        luminosite.niveau * secteur.panneau /
                                                                        10::double precision
           ELSE sum(besoin_necessaire.am) - luminosite.niveau * secteur.panneau / 10::double precision
           END                                                    AS batterie
FROM luminosite
         JOIN besoin_necessaire ON luminosite.date = besoin_necessaire.date
         JOIN secteur ON besoin_necessaire.secteur_id = secteur.id
GROUP BY luminosite.date, luminosite.heure, secteur.id, luminosite.niveau, secteur.panneau;

alter table consommation_necessaire
    owner to postgres;

