create view consommation_necessaire(secteur, date, heure, panneau, batterie) as
SELECT secteur.id                                                AS secteur,
       luminosite.date,
       luminosite.heure,
       luminosite.niveau * source.panneau / 10::double precision AS panneau,
       CASE
           WHEN EXTRACT(hour FROM luminosite.heure) >= 12::numeric THEN besoin_necessaire.pm -
                                                                        luminosite.niveau * source.panneau /
                                                                        10::double precision
           ELSE besoin_necessaire.am - luminosite.niveau * source.panneau / 10::double precision
           END                                                   AS batterie
FROM luminosite,
     secteur
         JOIN source ON secteur.id = source.secteur_id
         CROSS JOIN besoin_necessaire;

alter table consommation_necessaire
    owner to postgres;

