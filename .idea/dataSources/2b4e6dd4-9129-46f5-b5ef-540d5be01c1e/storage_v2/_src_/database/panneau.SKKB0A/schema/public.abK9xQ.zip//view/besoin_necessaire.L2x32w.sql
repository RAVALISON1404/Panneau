create view besoin_necessaire(date, am, pm) as
SELECT besoin.date,
       besoin.puissance * sum(nbr_pers.am)::double precision AS am,
       besoin.puissance * sum(nbr_pers.pm)::double precision AS pm
FROM secteur
         JOIN besoin ON secteur.id = besoin.secteur_id
         JOIN salle ON secteur.id = salle.secteur_id
         JOIN nbr_pers ON salle.id = nbr_pers.salle_id
GROUP BY besoin.date, besoin.puissance;

alter table besoin_necessaire
    owner to postgres;

